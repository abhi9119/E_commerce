from django.urls import path
from.import views 

urlpatterns = [
    path('',views.home,name='home'),
    path('home',views.home,name='home'),
    path('shopcart',views.shopcart,name='shopcart'),
    path('contact',views.contact,name='contact'),  
    path('about',views.about,name='about'),  
    path('profile',views.profile,name='profile'),  
    path('shop',views.shop,name='shop'), 

    
]
