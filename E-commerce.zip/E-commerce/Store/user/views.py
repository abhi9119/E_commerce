from django.shortcuts import render
from user.models import Contact,Product
from django.contrib import messages
from math import ceil


# Create your views here.
def shopcart(request):
    return render(request,"shopcart.html")

def shop(request):
    allProds=[]
    catProds= Product.objects.values('category','id')
    cats = {item['category'] for item in catProds}
    for cat in cats:
        prod= Product.objects.filter(category=cat)
        n=len(prod)
        nSlides = n // 4 + ceil(n / 4) - (n // 4)
        allProds.append([prod,range(1,nSlides),nSlides])

    params= {'allProds':allProds}   

    return render(request,"shop.html",params)





def contact(request):
    if request.method == "POST":
        name=request.POST["name"]
        email=request.POST["email"]
        message=request.POST["message"]
        myquery=Contact(name=name,email=email,message=message)
        myquery.save()
        messages.info(request,"WE WILL GET BACK TO YOU SOON...")
        
       
    return render(request,"contact.html")

def home(request):
    return render(request,"home.html")

def about(request):
    return render(request,"about.html")

def profile(request):
    return render(request,"profile.html")