from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

# Create your views here.





def signup(request):
    if request.method=='POST':
        username=request.POST["email"]
        email=request.POST["email"]
        password=request.POST["pass1"]
        confirm_password=request.POST["pass2"]
        if password!=confirm_password:
           messages.success(request,("PASSWORD DOES MATCH"))

    
        user = User.objects.create_user(email,email,password)
        user.save()
        messages.success(request,("USER HAS BEEN CREATED SUCCESSFULLY"))
        return redirect("/authentication/login")
    return render(request,"authentication/signup.html")



def handlelogin(request):
    if request.method == "POST":
       username = request.POST["username"]
       password = request.POST["pass1"]
       User = authenticate(username=username, password=password)
       if User is not None:
        login(request, User)
        return render(request,"home.html")
       

       else:
          messages.success(request,("There Was An Error While Login,User Not Found!!!"))
          return redirect('/authentication/signup')
    

    return render(request,'authentication/login.html')
     



def handlelogout(request):
    logout(request)
    messages.info(request,"Logout Success")
   
    return redirect('/authentication/login')




